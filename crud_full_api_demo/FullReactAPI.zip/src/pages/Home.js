function Home(){
    return(<h1>Home page here</h1>);
}

export default Home;